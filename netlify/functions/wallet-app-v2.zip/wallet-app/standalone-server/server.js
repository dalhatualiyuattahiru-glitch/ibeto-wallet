/**
 * Wallet App — Backend
 * Zero external dependencies. Run with: node server.js
 *
 * Serves the frontend (../frontend) as static files AND exposes a JSON API
 * under /api/*. Data is persisted to data/db.json (a flat-file "database").
 *
 * ⚠️ This is a learning / prototype backend, not a production payment system.
 * Real money movement requires a licensed payment processor, PCI-compliant
 * storage, fraud checks, idempotency keys, and proper transaction isolation.
 * Everything here (funding, withdrawals, bill payments) is SIMULATED —
 * no real bank, card, or biller is ever contacted.
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 4000;
const DB_PATH = path.join(__dirname, 'data', 'db.json');
const FRONTEND_DIR = path.join(__dirname, '..', 'frontend');

// Demo-only secret for signing session tokens. In a real app this comes
// from an environment variable and is never committed to source control.
const TOKEN_SECRET = 'wallet-demo-secret-change-me';
const TOKEN_TTL_MS = 1000 * 60 * 60 * 12; // 12 hours

// ---------------------------------------------------------------------------
// Tiny flat-file "database"
// ---------------------------------------------------------------------------

function readDB() {
  if (!fs.existsSync(DB_PATH)) {
    const initial = { users: [], transactions: [] };
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
    fs.writeFileSync(DB_PATH, JSON.stringify(initial, null, 2));
    return initial;
  }
  return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
}

function writeDB(db) {
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}

// ---------------------------------------------------------------------------
// Password hashing (scrypt) — no plaintext passwords are ever stored
// ---------------------------------------------------------------------------

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return { salt, hash };
}

function verifyPassword(password, salt, hash) {
  const check = crypto.scryptSync(password, salt, 64).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(check), Buffer.from(hash));
}

// ---------------------------------------------------------------------------
// Session tokens: base64(userId.expiry) + "." + HMAC signature
// ---------------------------------------------------------------------------

function createToken(userId) {
  const expiry = Date.now() + TOKEN_TTL_MS;
  const payload = Buffer.from(`${userId}.${expiry}`).toString('base64url');
  const sig = crypto.createHmac('sha256', TOKEN_SECRET).update(payload).digest('hex');
  return `${payload}.${sig}`;
}

function verifyToken(token) {
  if (!token || typeof token !== 'string' || !token.includes('.')) return null;
  const [payload, sig] = token.split('.');
  const expectedSig = crypto.createHmac('sha256', TOKEN_SECRET).update(payload).digest('hex');
  if (sig !== expectedSig) return null;
  const decoded = Buffer.from(payload, 'base64url').toString('utf8');
  const [userId, expiryStr] = decoded.split('.');
  if (Date.now() > Number(expiryStr)) return null;
  return userId;
}

function getAuthedUser(req, db) {
  const authHeader = req.headers['authorization'] || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
  const userId = verifyToken(token);
  if (!userId) return null;
  return db.users.find((u) => u.id === userId) || null;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function genId() {
  return crypto.randomUUID();
}

function sendJSON(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(body),
  });
  res.end(body);
}

function parseBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (chunk) => {
      data += chunk;
      if (data.length > 1e6) req.destroy(); // basic guard against huge bodies
    });
    req.on('end', () => {
      if (!data) return resolve({});
      try {
        resolve(JSON.parse(data));
      } catch (e) {
        reject(new Error('Invalid JSON body'));
      }
    });
    req.on('error', reject);
  });
}

function isValidEmail(email) {
  return typeof email === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function toCents(amount) {
  // Store balances as integer cents to avoid floating point drift.
  return Math.round(Number(amount) * 100);
}

function publicUser(user) {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    accountNumber: user.accountNumber,
    balance: user.balanceCents / 100,
    createdAt: user.createdAt,
  };
}

function recordTransaction(db, entry) {
  const tx = {
    id: genId(),
    createdAt: new Date().toISOString(),
    ...entry,
  };
  db.transactions.unshift(tx);
  return tx;
}

function genAccountNumber(db) {
  let acc;
  do {
    acc = String(Math.floor(1000000000 + Math.random() * 9000000000));
  } while (db.users.some((u) => u.accountNumber === acc));
  return acc;
}

// ---------------------------------------------------------------------------
// API route handlers
// ---------------------------------------------------------------------------

const routes = {
  'POST /api/register': async (req, res, db) => {
    const { name, email, password } = await parseBody(req);
    if (!name || !isValidEmail(email) || !password || password.length < 6) {
      return sendJSON(res, 400, {
        error: 'Provide a name, a valid email, and a password of at least 6 characters.',
      });
    }
    if (db.users.some((u) => u.email.toLowerCase() === email.toLowerCase())) {
      return sendJSON(res, 409, { error: 'An account with that email already exists.' });
    }
    const { salt, hash } = hashPassword(password);
    const user = {
      id: genId(),
      name,
      email,
      passwordSalt: salt,
      passwordHash: hash,
      accountNumber: genAccountNumber(db),
      balanceCents: 0,
      createdAt: new Date().toISOString(),
    };
    db.users.push(user);
    recordTransaction(db, {
      userId: user.id,
      type: 'account_opened',
      amount: 0,
      status: 'completed',
      description: 'Wallet account opened',
    });
    writeDB(db);
    const token = createToken(user.id);
    sendJSON(res, 201, { token, user: publicUser(user) });
  },

  'POST /api/login': async (req, res, db) => {
    const { email, password } = await parseBody(req);
    const user = db.users.find((u) => u.email.toLowerCase() === (email || '').toLowerCase());
    if (!user || !verifyPassword(password || '', user.passwordSalt, user.passwordHash)) {
      return sendJSON(res, 401, { error: 'Incorrect email or password.' });
    }
    const token = createToken(user.id);
    sendJSON(res, 200, { token, user: publicUser(user) });
  },

  'GET /api/me': async (req, res, db, user) => {
    if (!user) return sendJSON(res, 401, { error: 'Please sign in again.' });
    sendJSON(res, 200, { user: publicUser(user) });
  },

  'POST /api/fund': async (req, res, db, user) => {
    if (!user) return sendJSON(res, 401, { error: 'Please sign in again.' });
    const { amount, source } = await parseBody(req);
    const cents = toCents(amount);
    if (!Number.isFinite(cents) || cents <= 0) {
      return sendJSON(res, 400, { error: 'Enter an amount greater than zero.' });
    }
    user.balanceCents += cents;
    const tx = recordTransaction(db, {
      userId: user.id,
      type: 'fund',
      direction: 'in',
      amount: cents / 100,
      status: 'completed',
      description: `Wallet funded from ${source || 'linked card'}`,
    });
    writeDB(db);
    sendJSON(res, 200, { user: publicUser(user), transaction: tx });
  },

  'POST /api/transfer': async (req, res, db, user) => {
    if (!user) return sendJSON(res, 401, { error: 'Please sign in again.' });
    const { recipient, amount, note } = await parseBody(req);
    const cents = toCents(amount);
    if (!Number.isFinite(cents) || cents <= 0) {
      return sendJSON(res, 400, { error: 'Enter an amount greater than zero.' });
    }
    if (!recipient) {
      return sendJSON(res, 400, { error: "Enter the recipient's email or account number." });
    }
    const target = db.users.find(
      (u) =>
        u.id !== user.id &&
        (u.email.toLowerCase() === String(recipient).toLowerCase() ||
          u.accountNumber === String(recipient))
    );
    if (!target) {
      return sendJSON(res, 404, { error: 'No wallet found for that email or account number.' });
    }
    if (user.balanceCents < cents) {
      return sendJSON(res, 400, { error: 'Insufficient balance for this transfer.' });
    }
    user.balanceCents -= cents;
    target.balanceCents += cents;
    const tx = recordTransaction(db, {
      userId: user.id,
      type: 'transfer',
      direction: 'out',
      amount: cents / 100,
      counterparty: target.name,
      status: 'completed',
      description: note || `Transfer to ${target.name}`,
    });
    recordTransaction(db, {
      userId: target.id,
      type: 'transfer',
      direction: 'in',
      amount: cents / 100,
      counterparty: user.name,
      status: 'completed',
      description: note || `Transfer from ${user.name}`,
    });
    writeDB(db);
    sendJSON(res, 200, { user: publicUser(user), transaction: tx });
  },

  'POST /api/withdraw': async (req, res, db, user) => {
    if (!user) return sendJSON(res, 401, { error: 'Please sign in again.' });
    const { amount, bankName, accountNumber } = await parseBody(req);
    const cents = toCents(amount);
    if (!Number.isFinite(cents) || cents <= 0) {
      return sendJSON(res, 400, { error: 'Enter an amount greater than zero.' });
    }
    if (!bankName || !accountNumber) {
      return sendJSON(res, 400, { error: 'Enter the destination bank name and account number.' });
    }
    if (user.balanceCents < cents) {
      return sendJSON(res, 400, { error: 'Insufficient balance for this withdrawal.' });
    }
    user.balanceCents -= cents;
    const tx = recordTransaction(db, {
      userId: user.id,
      type: 'withdrawal',
      direction: 'out',
      amount: cents / 100,
      status: 'completed',
      description: `Withdrawal to ${bankName} ••••${String(accountNumber).slice(-4)}`,
    });
    writeDB(db);
    sendJSON(res, 200, { user: publicUser(user), transaction: tx });
  },

  'POST /api/pay-bill': async (req, res, db, user) => {
    if (!user) return sendJSON(res, 401, { error: 'Please sign in again.' });
    const { billType, provider, customerId, amount } = await parseBody(req);
    const cents = toCents(amount);
    if (!Number.isFinite(cents) || cents <= 0) {
      return sendJSON(res, 400, { error: 'Enter an amount greater than zero.' });
    }
    if (!billType || !provider || !customerId) {
      return sendJSON(res, 400, {
        error: 'Choose a bill type, provider, and customer/account ID.',
      });
    }
    if (user.balanceCents < cents) {
      return sendJSON(res, 400, { error: 'Insufficient balance for this payment.' });
    }
    user.balanceCents -= cents;
    const tx = recordTransaction(db, {
      userId: user.id,
      type: 'bill',
      direction: 'out',
      amount: cents / 100,
      status: 'completed',
      description: `${billType} — ${provider} (${customerId})`,
    });
    writeDB(db);
    sendJSON(res, 200, { user: publicUser(user), transaction: tx });
  },

  'GET /api/transactions': async (req, res, db, user) => {
    if (!user) return sendJSON(res, 401, { error: 'Please sign in again.' });
    const history = db.transactions
      .filter((t) => t.userId === user.id)
      .slice(0, 200);
    sendJSON(res, 200, { transactions: history });
  },
};

// ---------------------------------------------------------------------------
// Static file serving for the frontend
// ---------------------------------------------------------------------------

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
};

function serveStatic(req, res) {
  let urlPath = decodeURIComponent(req.url.split('?')[0]);
  if (urlPath === '/') urlPath = '/index.html';
  const filePath = path.join(FRONTEND_DIR, urlPath);

  // Prevent path traversal outside the frontend directory.
  if (!filePath.startsWith(FRONTEND_DIR)) {
    res.writeHead(403);
    return res.end('Forbidden');
  }

  fs.readFile(filePath, (err, content) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      return res.end('Not found');
    }
    const ext = path.extname(filePath);
    res.writeHead(200, { 'Content-Type': MIME_TYPES[ext] || 'application/octet-stream' });
    res.end(content);
  });
}

// ---------------------------------------------------------------------------
// Server
// ---------------------------------------------------------------------------

const server = http.createServer(async (req, res) => {
  const routeKey = `${req.method} ${req.url.split('?')[0]}`;

  if (routes[routeKey]) {
    const db = readDB();
    const user = getAuthedUser(req, db);
    try {
      await routes[routeKey](req, res, db, user);
    } catch (err) {
      sendJSON(res, 400, { error: err.message || 'Something went wrong.' });
    }
    return;
  }

  if (req.url.startsWith('/api/')) {
    return sendJSON(res, 404, { error: 'Unknown API route.' });
  }

  serveStatic(req, res);
});

server.listen(PORT, () => {
  console.log(`Wallet app running at http://localhost:${PORT}`);
});
